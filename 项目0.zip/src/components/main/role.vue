<template>
    <div>
        <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">
                <a href="/">首页</a>
            </el-breadcrumb-item>
            <el-breadcrumb-item>角色列表</el-breadcrumb-item>
        </el-breadcrumb>

        <el-button type="primary" @click="handleAdd">添加</el-button>
        <el-table :data="rolelist" style="width: 100%;margin-bottom: 20px;" row-key="id" border>
            <el-table-column prop="rolename" label="名称" width="150"></el-table-column>
            <el-table-column prop="status" label="状态" width="150">
                <template slot-scope="scope">
                    <el-tag
                        :type="scope.row.status == 1 ? 'success':'danger'"
                        effect="dark"
                    >{{scope.row.status == 1 ?"启用":"禁用"}}</el-tag>
                </template>
            </el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button size="mini" @click="handleEdit(scope.row)" k>编辑</el-button>
                    <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>

        <!-- 弹窗 -->
        <el-dialog :title="'角色'+tip" :visible.sync="dialogFormVisible" width="50%">
            <el-form :model="ruleForm" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                <el-form-item
                    label="菜单名称"
                    prop="emil"
                    :rules="[{ required: true, message: '请输入菜单名称', trigger: 'blur' }]"
                >
                    <el-input v-model="ruleForm.rolename"></el-input>
                </el-form-item>

                <el-form-item label="菜单权限">
                    <el-tree
                        :data="menulist"
                        show-checkbox
                        node-key="id"
                        :props="{label:'title',children:'children'}"
                    ></el-tree>
                </el-form-item>

                <el-form-item label="状态">
                    <el-switch v-model="ruleForm.status" @change="changeStatus"></el-switch>
                </el-form-item>

                <el-form-item>
                    <el-button @click="dialogFormVisible = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit">确定</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        const menulist = this.menulist;
        return {
            //角色列表
            rolelist: [],
            //菜单列表
            menulist: [],
            ruleForm: {
                rolename: "", //角色名称
                menus: "", //角色权限
                status: "", //状态1正常2禁用,
            },
            dialogFormVisible: false,
        };
    },

    mounted() {
        this.$http.get("/api/rolelist").then((res) => {
            console.log(res);
            if (res.code == 200) {
                this.rolelist = res.list || [];
            } else {
                this.$message({
                    type: "warn",
                    message: res.msg,
                });
            }
        });

        this.$http.get("/api/menulist?istree=1").then((res) => {
            console.log(res, 111);
            if (res.code == 200) {
                this.menulist = res.list || [];
            } else {
                this.$message({
                    type: "warn",
                    message: res.msg,
                });
            }
        });
    },

    methods: {
        //添加
        handleAdd() {
            this.dialogFormVisible = true;
            // console.log();
        },
        //编辑
        handleEdit() {
            console.log("编辑");
        },

        //删除
        handleDelete() {
            console.log("删除");
        },
    },
};
</script>