<template>
    <div>
        seckill
    </div>
</template>

<script>
export default {
    
}
</script>