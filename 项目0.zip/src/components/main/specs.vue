<template>
    <div>
        specs
    </div>
</template>

<script>
export default {
    
}
</script>