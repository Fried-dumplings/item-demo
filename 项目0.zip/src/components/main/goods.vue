<template>
    <div>
        goods
    </div>
</template>

<script>
export default {
    
}
</script>